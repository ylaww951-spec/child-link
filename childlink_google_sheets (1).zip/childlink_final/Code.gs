// ═══════════════════════════════════════════════════════════
//  ChildLink – Google Apps Script Backend
//  نسخ هذا الكود كله في Google Apps Script وانشر كـ Web App
// ═══════════════════════════════════════════════════════════

const SHEET_NAME_MISSING = 'مفقودين';
const SHEET_NAME_FOUND   = 'معثور عليهم';
const DRIVE_FOLDER_NAME  = 'ChildLink - صور البلاغات';

// ─── الحصول على الـ Spreadsheet أو إنشاؤه ───
function getOrCreateSpreadsheet() {
  const files = DriveApp.getFilesByName('ChildLink - بيانات البلاغات');
  if (files.hasNext()) {
    return SpreadsheetApp.open(files.next());
  }

  const ss = SpreadsheetApp.create('ChildLink - بيانات البلاغات');

  // ورقة المفقودين
  const missingSheet = ss.getActiveSheet();
  missingSheet.setName(SHEET_NAME_MISSING);
  missingSheet.setRightToLeft(true);
  const missingHeaders = ['ID','الاسم','العمر','الجنس','المنطقة','المحافظة',
    'ولي الأمر','رقم الهاتف','الوصف','رابط الصورة',
    'تاريخ الفقدان','الحالة','تاريخ الإضافة'];
  missingSheet.appendRow(missingHeaders);
  missingSheet.getRange(1,1,1,missingHeaders.length)
    .setBackground('#0D3B1E').setFontColor('#FFFFFF')
    .setFontWeight('bold').setFontSize(11);

  // ورقة المعثور عليهم
  const foundSheet = ss.insertSheet(SHEET_NAME_FOUND);
  foundSheet.setRightToLeft(true);
  const foundHeaders = ['ID','الاسم','العمر التقريبي','الجنس','المنطقة','المحافظة',
    'المُبلِّغ','رقم الهاتف','الوصف','رابط الصورة',
    'الحالة الصحية','مكان الطفل','تاريخ الاكتشاف','الحالة','تاريخ الإضافة'];
  foundSheet.appendRow(foundHeaders);
  foundSheet.getRange(1,1,1,foundHeaders.length)
    .setBackground('#1B5E20').setFontColor('#FFFFFF')
    .setFontWeight('bold').setFontSize(11);

  return ss;
}

function getSheet(sheetName) {
  return getOrCreateSpreadsheet().getSheetByName(sheetName);
}

// ─── GET – جلب البلاغات ───
function doGet(e) {
  try {
    const action = e.parameter.action;
    if (action === 'missing') return sendJSON(getReports(SHEET_NAME_MISSING, 'missing'));
    if (action === 'found')   return sendJSON(getReports(SHEET_NAME_FOUND,   'found'));
    return sendJSON({success: false, error: 'action غير معروف'});
  } catch(err) {
    return sendJSON({success: false, error: err.message});
  }
}

function getReports(sheetName, type) {
  const sheet = getSheet(sheetName);
  const rows  = sheet.getDataRange().getValues();
  if (rows.length <= 1) return {success: true, data: []};

  const headers = rows[0];
  const records = [];

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row[0]) continue; // سطر فارغ

    const status = row[type === 'missing' ? 11 : 13];
    if (status !== 'active' && status !== 'matched') continue;

    if (type === 'missing') {
      records.push({
        id:          row[0],
        name:        row[1],
        age:         row[2],
        gender:      row[3],
        area:        row[4],
        region:      row[5],
        guardian:    row[6],
        phone:       row[7],
        description: row[8],
        image_path:  row[9],
        lost_at:     row[10],
        status:      row[11],
        created_at:  row[12]
      });
    } else {
      records.push({
        id:           row[0],
        name:         row[1],
        age:          row[2],
        gender:       row[3],
        area:         row[4],
        region:       row[5],
        reporter:     row[6],
        phone:        row[7],
        description:  row[8],
        image_path:   row[9],
        health:       row[10],
        child_status: row[11],
        found_at:     row[12],
        status:       row[13],
        created_at:   row[14]
      });
    }
  }

  return {success: true, data: records};
}

// ─── POST – حفظ بلاغ جديد ───
function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    if (payload.type === 'missing') return sendJSON(saveMissing(payload));
    if (payload.type === 'found')   return sendJSON(saveFound(payload));
    return sendJSON({success: false, error: 'type غير معروف'});
  } catch(err) {
    return sendJSON({success: false, error: err.message});
  }
}

function saveMissing(d) {
  const sheet    = getSheet(SHEET_NAME_MISSING);
  const id       = Date.now();
  const imageUrl = d.imageBase64 ? saveImage(d.imageBase64, 'missing_' + id) : '';
  const now      = Utilities.formatDate(new Date(), 'Africa/Cairo', 'yyyy-MM-dd HH:mm:ss');

  sheet.appendRow([
    id, d.name||'', d.age||'', d.gender||'',
    d.area||'', d.region||'', d.guardian||'', d.phone||'',
    d.description||'', imageUrl, d.lost_at||'', 'active', now
  ]);

  // تنسيق الصف الجديد
  const lastRow = sheet.getLastRow();
  sheet.getRange(lastRow, 1, 1, 13).setBackground(lastRow % 2 === 0 ? '#F1F8E9' : '#FFFFFF');

  return {success: true, id: id, image_path: imageUrl};
}

function saveFound(d) {
  const sheet    = getSheet(SHEET_NAME_FOUND);
  const id       = Date.now();
  const imageUrl = d.imageBase64 ? saveImage(d.imageBase64, 'found_' + id) : '';
  const now      = Utilities.formatDate(new Date(), 'Africa/Cairo', 'yyyy-MM-dd HH:mm:ss');

  sheet.appendRow([
    id, d.name||'مجهول الهوية', d.age||'', d.gender||'unknown',
    d.area||'', d.region||'', d.reporter||'', d.phone||'',
    d.description||'', imageUrl, d.health||'good',
    d.child_status||'with_reporter', d.found_at||'', 'active', now
  ]);

  const lastRow = sheet.getLastRow();
  sheet.getRange(lastRow, 1, 1, 15).setBackground(lastRow % 2 === 0 ? '#E8F5E9' : '#FFFFFF');

  return {success: true, id: id, image_path: imageUrl};
}

// ─── حفظ الصورة في Google Drive ───
function saveImage(base64Data, filename) {
  try {
    let folder;
    const folders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
    folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(DRIVE_FOLDER_NAME);

    const match    = base64Data.match(/^data:(image\/[a-z+]+);base64,/);
    const mimeType = match ? match[1] : 'image/jpeg';
    const ext      = mimeType.split('/')[1].replace('jpeg','jpg');
    const pureB64  = base64Data.replace(/^data:image\/[a-z+]+;base64,/, '');

    const blob = Utilities.newBlob(Utilities.base64Decode(pureB64), mimeType, filename + '.' + ext);
    const file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

    return 'https://drive.google.com/uc?export=view&id=' + file.getId();
  } catch(err) {
    Logger.log('Image save error: ' + err.message);
    return '';
  }
}

// ─── CORS + JSON Response ───
function sendJSON(data) {
  const output = ContentService.createTextOutput(JSON.stringify(data));
  output.setMimeType(ContentService.MimeType.JSON);
  return output;
}

// للـ CORS preflight (بعض المتصفحات بتطلبه)
function doOptions(e) {
  return ContentService.createTextOutput('');
}
